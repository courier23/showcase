function mpc = case30
%CASE30    Power flow data for 30 bus, 6 generator case.
%   Please see CASEFORMAT for details on the case file format.
%
%   Based on data from ...
%     Alsac, O. & Stott, B., "Optimal Load Flow with Steady State Security",
%     IEEE Transactions on Power Apparatus and Systems, Vol. PAS 93, No. 3,
%     1974, pp. 745-751.
%   ... with branch parameters rounded to nearest 0.01, shunt values divided
%   by 100 and shunt on bus 10 moved to bus 5, load at bus 5 zeroed out.
%   Generator locations, costs and limits and bus areas were taken from ...
%     Ferrero, R.W., Shahidehpour, S.M., Ramesh, V.C., "Transaction analysis
%     in deregulated power systems using game theory", IEEE Transactions on
%     Power Systems, Vol. 12, No. 3, Aug 1997, pp. 1340-1347.
%   Generator Q limits were derived from Alsac & Stott, using their Pmax
%   capacities. V limits and line |S| limits taken from Alsac & Stott.

%   MATPOWER

%% MATPOWER Case Format : Version 2
mpc.version = '2';

%%-----  Power Flow Data  -----%%
%% system MVA base
mpc.baseMVA = 100;

%% bus data
%	bus_i	type	Pd	Qd	Gs	Bs	area	Vm	Va	baseKV	zone	Vmax	Vmin
mpc.bus = [
	1	3	0       0       0	0	1	1	0	135     1	1.1 	0.95;
	2	2	21.7	12.7	0	0	1	1	0	135     1	1.1     0.95;
	3	1	2.4     1.2     0	0	1	1	0	135     1	1.05	0.95;
	4	1	7.6     1.6     0	0	1	1	0	135     1	1.05	0.95;
	5	2	94.2    19      0	0.19	1	1	0	135     1	1.1	0.95;
	6	1	0       0       0   0	1	1	0	135     1	1.05	0.95;
	7	1	22.8	10.9	0	0	1	1	0	135     1	1.05	0.95;
	8	2	30      30      0	0	1	1	0	135     1	1.10	0.95;
	9	1	0       0       0	0	1	1	0	135     1	1.05	0.95;
	10	1	5.8     2       0	0	3	1	0	135     1	1.05	0.95;
	11	2	0       0       0	0	1	1	0	135     1	1.10	0.95;
	12	1	11.2	7.5     0	0	2	1	0	135     1	1.05	0.95;
	13	2	0       0       0	0	2	1	0	135     1	1.10    0.95;
	14	1	6.2     1.6     0	0	2	1	0	135     1	1.05	0.95;
	15	1	8.2     2.5     0	0	2	1	0	135     1	1.05	0.95;
	16	1	3.5     1.8     0	0	2	1	0	135     1	1.05	0.95;
	17	1	9       5.8     0	0	2	1	0	135     1	1.05	0.95;
	18	1	3.2     0.9     0	0	2	1	0	135     1	1.05	0.95;
	19	1	9.5     3.4     0	0	2	1	0	135     1	1.05	0.95;
	20	1	2.2     0.7     0	0	2	1	0	135     1	1.05	0.95;
	21	1	17.5	11.2	0	0	3	1	0	135     1	1.05	0.95;
	22	1	0       0       0	0	3	1	0	135     1	1.05    0.95;
	23	1	3.2     1.6     0	0	2	1	0	135     1	1.05     0.95;
	24	1	8.7     6.7     0	0.04	3	1	0	135     1	1.05	0.95;
	25	1	0       0       0	0	3	1	0	135     1	1.05	0.95;
	26	1	3.5     2.3     0	0	3	1	0	135     1	1.05	0.95;
	27	1	0       0       0	0	3	1	0	135     1	1.05    0.95;
	28	1	0       0       0	0	1	1	0	135     1	1.05	0.95;
	29	1	2.4     0.9     0	0	3	1	0	135     1	1.05	0.95;
	30	1	10.6	1.9     0	0	3	1	0	135     1	1.05	0.95;
];

%% generator data
%	bus	Pg	Qg	Qmax	Qmin	Vg	mBase	status	Pmax	Pmin	Pc1	Pc2	Qc1min	Qc1max	Qc2min	Qc2max	ramp_agc	ramp_10	ramp_30	ramp_q	apf
mpc.gen = [
	1    99.211     -3.99	150.0	-20     1.0     100	1	140	50 0 0 0 0 0 0 0 0 0 0;
	2    80.00      50.0	60.0    -20     1.0     100	1	80	20 0 0 0 0 0 0 0 0 0 0;
	5    20.00      37.0	35.0 	-30 	1.0     100	1	60	10 0 0 0 0 0 0 0 0 0 0;
	8    50.00      37.3	40.0   	-15 	1.0 	100	1	35	10 0 0 0 0 0 0 0 0 0 0;
    11   60.00      37.3	30.0  	-25 	1.0 	100	1	60	10 0 0 0 0 0 0 0 0 0 0;
    13   20.00      37.3	25.0  	-20 	1.0 	100	1	60	10 0 0 0 0 0 0 0 0 0 0;
];

%% branch data
%	fbus	tbus	r	x	b	rateA	rateB	rateC	ratio	angle	status	angmin	angmax
mpc.branch = [
1	2	0.0192	0.0575	0.0528	130	130	130	0	0	1	-360	360;
1	3	0.0452	0.1652	0.0408	130	130	130	0	0	1	-360	360;
2	4	0.057	0.1737	0.0368	65	65	65	0	0	1	-360	360;
3	4	0.0132	0.0379	0.0084	130	130	130	0	0	1	-360	360;
2	5	0.0472	0.1983	0.0418	130	130	130	0	0	1	-360	360;
2	6	0.0581	0.1763	0.0374	65	65	65	0	0	1	-360	360;
4	6	0.0119	0.0414	0.009	90	90	90	0	0	1	-360	360;
5	7	0.046	0.116	0.0204	70	70	70	0	0	1	-360	360;
6	7	0.0267	0.082	0.017	130	130	130	0	0	1	-360	360;
6	8	0.012	0.042	0.009	32	32	32	0	0	1	-360	360;
6	9	0.00	0.208	0.00	65	65	65	0	0	1	-360	360;
6	10	0.00	0.556	0.00	32	32	32	0	0	1	-360	360;
9	11	0.00	0.208	0.00	65	65	65	0	0	1	-360	360;
9	10	0.00	0.11	0.00	65	65	65	0	0	1	-360	360;
4	12	0.00	0.256	0.00	65	65	65	0	0	1	-360	360;
12	13	0.00	0.14	0.00	65	65	65	0	0	1	-360	360;
12	14	0.1231	0.2559	0.00	32	32	32	0	0	1	-360	360;
12	15	0.0662	0.1304	0.00	32	32	32	0	0	1	-360	360;
12	16	0.0945	0.1987	0.00	32	32	32	0	0	1	-360	360;
14	15	0.221	0.1997	0.00	16	16	16	0	0	1	-360	360;
16	17	0.0524	0.1923	0.00	16	16	16	0	0	1	-360	360;
15	18	0.1073	0.2185	0.00	16	16	16	0	0	1	-360	360;
18	19	0.0639	0.1292	0.00	16	16	16	0	0	1	-360	360;
19	20	0.034	0.068	0.00	32	32	32	0	0	1	-360	360;
10	20	0.0936	0.209	0.00	32	32	32	0	0	1	-360	360;
10	17	0.0324	0.0845	0.00	32	32	32	0	0	1	-360	360;
10	21	0.0348	0.0749	0.00	32	32	32	0	0	1	-360	360;
10	22	0.0727	0.1499	0.00	32	32	32	0	0	1	-360	360;
21	22	0.0116	0.0236	0.00	32	32	32	0	0	1	-360	360;
15	23	0.10	0.202	0.00	16	16	16	0	0	1	-360	360;
22	24	0.115	0.179	0.00	16	16	16	0	0	1	-360	360;
23	24	0.132	0.27	0.00	16	16	16	0	0	1	-360	360;
24	25	0.1885	0.3292	0.00	16	16	16	0	0	1	-360	360;
25	26	0.2544	0.38	0.00	16	16	16	0	0	1	-360	360;
25	27	0.1093	0.2087	0.00	16	16	16	0	0	1	-360	360;
28	27	0.00	0.396	0.00	65	65	65	0	0	1	-360	360;
27	29	0.2198	0.4153	0.00	16	16	16	0	0	1	-360	360;
27	30	0.3202	0.6027	0.00	16	16	16	0	0	1	-360	360;
29	30	0.2399	0.4533	0.00	16	16	16	0	0	1	-360	360;
8	28	0.0636	0.20	0.0428	32	32	32	0	0	1	-360	360;
6	28	0.0169	0.0599	0.013	32	32	32	0	0	1	-360	360;
];

%%-----  OPF Data  -----%%
%% generator cost data
%	1	startup	shutdown	n	x1	y1	...	xn	yn
%	2	startup	shutdown	n	c(n-1)	...	c0
mpc.gencost = [
	2	0	0	3	0.0     2.00	0.00375;
	2	0	0	3	0.0     1.75	0.0175;
	2	0	0	3	0.0     3.00	0.025;
	2	0	0	3	0.0     3.25	0.00834;
	2	0	0	3	0.0     3.00	0.025;
	2	0	0	3	0.0 	3.00	0.025;
];

% 光伏辐照度场景服从对数正态分布
% 安装位置为bus13,替换原gen, no. bus costcoeff
sgenpar = [1   13  1.60];
mu = 6; sigma = 0.6;
Psr = 50; % [MW] Equivalent rated power output of the PV generator
Gstd = 800; %[W/m2] Solar irradiation in the standard enviroment
Rc = 120; % [W/m2] A certain irradiation
mcarlo = 10; % No. of Montecalro scenarios 原为8000
G1 = lognrnd(mu,sigma,mcarlo,1);
% Power calculation
G1und = G1(G1<=Rc);
G1over = G1(G1>Rc);
P1und = Psr*(G1und.^2/(Gstd*Rc));
P1over = Psr*(G1over./Gstd);
mpc.PV_scenario = vertcat(P1und,P1over);


% 风速场景服从weibull分布
% 安装位置为bus5和11，替换原gen, no. bus costcoeff
wgenpar = [1   5   1.60;
           2   11  1.75];
%weibull分布参数
scale = [9 10]; % Enter shape parameters of 2 windfarms for Weibull dist
shape = [2 2]; % Enter shape parameters of 2 windfarms for Weibull dist
Vin = 3; Vout = 25; Vr = 16; Pr = 3; % Cut-in, cut-out, rated speed and rated power of turbine
NT1=2;NT2=3;
W1 = wblrnd(scale(1),shape(1),mcarlo,1);
W1und = W1((W1<Vin)|(W1>Vout));
W1_linear = W1((W1>=Vin)&(W1<=Vr));
W1over = W1((W1>=Vr)&(W1<=Vout));
PW1und = 0*W1und;
PW1_linear = Pr*NT1*(W1_linear-Vin)/(Vr-Vin);
PW1over = Psr*NT1*W1over;
mpc.W_scenario(:,1) = vertcat(PW1und,PW1_linear,PW1over);

W2 = wblrnd(scale(2),shape(2),mcarlo,1);
W2und = W2((W2<Vin)|(W2>Vout));
W2_linear = W2((W2>=Vin)&(W2<=Vr));
W2over = W2((W2>=Vr)&(W2<=Vout));
PW2und = 0*W2und;
PW2_linear = Pr*NT2*(W2_linear-Vin)/(Vr-Vin);
PW2over = Psr*NT2*W2over;
mpc.W_scenario(:,2) = vertcat(PW2und,PW2_linear,PW2over);

a1=1;

